
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'ap-northeast-2' })

exports.handler = (event, context, callback) => {
    if (parseInt(event.price) > 0) {


        let checkerParamsForOnSale = {
            TableName: "Shoes",
            Key: {
                ProductID: event.pid,
                Seller: event.authID
            }
        }
        let StoreData = {}
        let ModelData = {}
        docClient.get(checkerParamsForOnSale, (err, data) => {
            if (err) {
                callback("err1", null)
            }
            else {

                if (data.Item.OnSale === 1) {
                    let checkerParamsForUpdate = {
                        TableName: "Shoes",
                        Key: {
                            ProductID: event.pid,
                            Seller: event.authID
                        },
                        UpdateExpression: "set OnSale = :b, Price = :c",
                        ExpressionAttributeValues: {
                            ":b": 2,
                            ":c": parseInt(event.price),
                        },
                        ReturnValues: "ALL_NEW"
                    }

                    docClient.update(checkerParamsForUpdate, (err, data2) => {
                        StoreData = data2;
                        if (err) {
                            callback("err2", null)
                        }
                        else {
                            let updateStock = {
                                TableName: "Stock",
                                Key: {
                                    Type: "Shoe",
                                    Model: StoreData.Attributes.Model
                                },
                                UpdateExpression: "add StockCount :AddOne",
                                ExpressionAttributeValues: {
                                    ":AddOne": 1,
                                },
                                ReturnValues: "ALL_NEW"
                            }
                            docClient.update(updateStock, (err, data3) => {
                                ModelData = data3;
                                let updateStock2 = {
                                    TableName: "Stock",
                                    Key: {
                                        Type: "Shoe",
                                        Model: ModelData.Attributes.Model
                                    },
                                    UpdateExpression: "set LowestPrice = :newPrice, Profit = (:newPrice - :ReleasePri2ce)",
                                    ExpressionAttributeValues: {
                                        ":zero": 0,
                                        ":newPrice": parseInt(event.price),
                                        ":ReleasePri2ce": ModelData.Attributes.ReleasePrice
                                    },
                                    ConditionExpression: "LowestPrice = :zero OR LowestPrice > :newPrice"
                                }

                                if (err) callback("err3", null);

                                else {
                                    docClient.update(updateStock2, (err, data4) => {
                                        if (err) { // when condition fail
                                            if (err.code === 'ConditionalCheckFailedException') {
                                                // add or change lowest price by size

                                                let updateStock3 = {
                                                    TableName: "Stock",
                                                    Key: {
                                                        Type: "Shoe",
                                                        Model: ModelData.Attributes.Model
                                                    },
                                                    UpdateExpression: "SET SizePrice.#number = :string",
                                                    ExpressionAttributeValues: { ":string": parseInt(event.price) },
                                                    ConditionExpression: "attribute_not_exists(SizePrice.#number) OR SizePrice.#number > :string"
                                                }

                                                docClient.update(updateStock3, (err, data6) => {
                                                    if (err) {
                                                        callback(err.errorType, null)
                                                        let x = 0
                                                        if (x === 1) {
                                                            let updateStock6 = {
                                                                TableName: "Stock",
                                                                Key: {
                                                                    Type: "Shoe",
                                                                    Model: ModelData.Attributes.Model
                                                                },
                                                                UpdateExpression: "SET SizePrice.#number = :string",
                                                                ExpressionAttributeValues: { ":string": parseInt(event.price) },
                                                                ExpressionAttributeNames: { "#number": StoreData.Attributes.Size }
                                                            }
                                                            // add or change lowest price by size
                                                            //updateStock.ConditionExpression = "SizePrice.#number"
                                                            docClient.update(updateStock6, (err, data5) => {
                                                                if (err) callback("err5", null);
                                                                else {
                                                                    // add new ticker lowest price
                                                                    context.done(null, "Depend Finish")
                                                                }
                                                            })
                                                        }
                                                        else {
                                                            callback(err.errorType, null)
                                                        }

                                                    }
                                                    // add new ticker highest price
                                                    else {
                                                        context.done(null, "Depend Finish")
                                                    }
                                                })
                                            }
                                            else {
                                                callback("err4", null);
                                            }
                                        }
                                        else {
                                            let updateStock4 = {
                                                TableName: "Stock",
                                                Key: {
                                                    Type: "Shoe",
                                                    Model: ModelData.Attributes.Model
                                                },
                                                UpdateExpression: "SET SizePrice.#number = :string",
                                                ExpressionAttributeValues: { ":string": parseInt(event.price) },
                                                ExpressionAttributeNames: { "#number": StoreData.Attributes.Size }
                                            }
                                            // add or change lowest price by size
                                            //updateStock.ConditionExpression = "SizePrice.#number"
                                            docClient.update(updateStock4, (err, data5) => {
                                                if (err) callback("err5", null);
                                                else {
                                                    // add new ticker lowest price
                                                    context.done(null, "Depend Finish")
                                                }
                                            })
                                        }
                                    })

                                }
                            })
                        }
                    })
                }
                else {
                    callback("err6", null);
                }
            }
        })
    }
    else {
        callback(err, null);
    }
}