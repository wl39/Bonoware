
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'ap-northeast-2' })

exports.handler = function (event, context, callback) {
    if (parseInt(event.price) > 0) {


        let checkerParamsForOnSale = {
            TableName: "Shoes",
            Key: {
                ProductID: event.pid,
                Seller: event.authID
            }
        }
        docClient.get(checkerParamsForOnSale, (err, data) => {
            if (err) {
                callback(err, null)
            }
            else {

                if (data.Item.OnSale === 1) {
                    let checkerParamsForUpdate = {
                        TableName: "Shoes",
                        Key: {
                            ProductID: event.pid,
                            Seller: event.authID
                        },
                        UpdateExpression: "set OnSale = :b, Price = :c",
                        ExpressionAttributeValues: {
                            ":b": 2,
                            ":c": parseInt(event.price),
                        },
                        ReturnValues: "ALL_NEW"
                    }

                    docClient.update(checkerParamsForUpdate, (err, data2) => {
                        if (err) {
                            callback(err, null);
                        }
                        else {
                            let updateStock = {
                                TableName: "Stock",
                                Key: {
                                    Type: "Shoe",
                                    Model: data2.Attributes.Model
                                },
                                UpdateExpression: "add StockCount :AddOne",
                                ExpressionAttributeValues: {
                                    ":AddOne": 1,
                                },
                                ReturnValues: "ALL_NEW"
                            }
                            docClient.update(updateStock, (err, data3) => {
                                updateStock.UpdateExpression = "set LowestPrice = :newPrice, Profit = (:newPrice - :ReleasePrice)"
                                updateStock.ConditionExpression = "LowestPrice = :zero OR LowestPrice > :newPrice"
                                updateStock.ExpressionAttributeValues = {
                                    ":zero": 0,
                                    ":newPrice": parseInt(event.price),
                                    ":ReleasePrice": data3.Attributes.ReleasePrice
                                }
                                if (err) callback(err, null);

                                else {
                                    docClient.update(updateStock, (err, data4) => {
                                        if (err) { // when condition fail
                                            if (err.code === 'ConditionalCheckFailedException') {
                                                // add or change lowest price by size
                                                updateStock.UpdateExpression = "SET SizePrice.#number = :string"
                                                updateStock.ExpressionAttributeNames = { "#number": data2.Attributes.Size }
                                                updateStock.ExpressionAttributeValues = { ":string": parseInt(event.price) }
                                                updateStock.ConditionExpression = "attribute_not_exists(SizePrice.#number) OR SizePrice.#number > :string"
                                                docClient.update(updateStock, (err, data6) => {
                                                    context.done(null, "finished")
                                                })
                                            }
                                            else {
                                                callback(err, null)
                                            }
                                        }
                                        else {
                                            // add or change lowest price by size
                                            updateStock.UpdateExpression = "SET SizePrice.#number = :string"
                                            updateStock.ExpressionAttributeNames = { "#number": data2.Attributes.Size }
                                            updateStock.ExpressionAttributeValues = { ":string": parseInt(event.price) }
                                            updateStock.ConditionExpression = undefined
                                            //updateStock.ConditionExpression = "SizePrice.#number"
                                            docClient.update(updateStock, (err, data5) => {
                                                if (err) callback(err, null);
                                                else {
                                                    context.done(null, "finished")
                                                }
                                            })
                                        }
                                    })

                                }
                            })
                            context.done(null, event)
                        }
                    })
                }
                else {
                    callback(err, null)
                }
            }
        })
    }
    else {
        callback(err, null)
    }
}