const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'ap-northeast-2' })

exports.handler = function (event, context, callback) {

    let param = {
        TableName: "Etc",
        Key: {
            Contents: "PopularSearch"
        },
        UpdateExpression: 'set #data.#date =  if_not_exists(#data.#date, :zero)+ :value',
        ExpressionAttributeNames: {
            "#data": "Ranking",
            "#date": event.productName
        },
        ExpressionAttributeValues: {
            ":value": 1,
            ":zero": 0
        },
    }

    docClient.update(param, (err, data) => {
        if (err) {
            callback(err, null)
        }
        else {
            param.Key.Contents = "DailySearch"
            docClient.update(param, (err, data) => {
                if (err) {
                    callback(err, null)
                }
                else {
                    param.Key.Contents = "WeeklySearch"
                    docClient.update(param, (err, data) => {
                        if (err) {
                            callback(err, null)
                        }
                        else {

                            context.done(null, event)
                        }
                    })
                }
            })
        }

    })
}


